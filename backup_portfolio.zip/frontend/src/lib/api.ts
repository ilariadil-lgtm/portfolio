const BASE_URL = 'http://localhost:8000/api';

export const api = {
  // Progetti
  getProjects: async () => {
    const response = await fetch(`${BASE_URL}/projects/`);
    if (!response.ok) throw new Error('Errore nel recupero dei progetti');
    return response.json();
  },

  // Contatti
  sendContactMessage: async (data: { name: string, email: string, subject: string, message: string }) => {
    const response = await fetch(`${BASE_URL}/contacts/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!response.ok) throw new Error("Errore nell'invio del messaggio");
    return response.json();
  },

  // Altri endpoint (Blog, FAQ, About, Services)
  getProject: (id: string | number) => fetch(`${BASE_URL}/projects/${id}/`).then(res => res.json()),
  getBlogPosts: () => fetch(`${BASE_URL}/blog/`).then(res => res.json()),
  getFaqs: () => fetch(`${BASE_URL}/faq/`).then(res => res.json()),
  getAbout: () => fetch(`${BASE_URL}/about/`).then(res => res.json()),
  getServices: () => fetch(`${BASE_URL}/services/`).then(res => res.json()),
};
